<?php
if(isset($_SESSION['log1'])=="")
{
	header("location:index.php");
}
?>