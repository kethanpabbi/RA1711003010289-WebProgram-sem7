<footer id="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="copyright">
                    <strong>Created by Team 13</strong>
                </div>
                <div class="credits">
                    Any queries? <a href="#">Contact Us</a>
                </div>
            </div>
        </div>
    </div>
</footer>